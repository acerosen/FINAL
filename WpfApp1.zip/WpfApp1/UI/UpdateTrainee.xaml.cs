﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace WpfApp1
{
    /// <summary>
    /// Interaction logic for UpdateTrainee.xaml
    /// </summary>
    public partial class UpdateTrainee : Window 
    {
        BE.Trainee trainee;
        BL.IBL bl;
        public UpdateTrainee()
        {
            InitializeComponent();
            trainee = new BE.Trainee();
            this.gridUpdateTrainee.DataContext = trainee;
            bl = BL.FactoryBL.getBL();
            ID.ItemsSource = from item in bl.GetAllTrainee()
                                   select item.ID;
        }
        private void Update_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                bl.UpdateTrainee(trainee);
                //order = new BE.Order();
                MessageBox.Show("the trainee " + trainee.FirstName + " updated  ", " Successfully updated! ");
                this.gridUpdateTrainee.DataContext = trainee;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        private void Delete_Click(object sender, RoutedEventArgs e)
        {
            try
            {

                bl.DeleteTrainee(trainee.ID);
                BE.Trainee or = new BE.Trainee();
                MessageBox.Show(trainee.ID + "'s \n" + "is Deleted, the number invitation is " + trainee.FirstName, "");
                ID.ItemsSource = from item in bl.GetAllTrainee()
                                       select item.FirstName;
                this.DataContext = trainee;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        private void TraineeID_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            trainee = bl.GetAllTrainee(O => O.FirstName == trainee.FirstName).FirstOrDefault();
            this.gridUpdateTrainee.DataContext = trainee;
        }
    }
}
